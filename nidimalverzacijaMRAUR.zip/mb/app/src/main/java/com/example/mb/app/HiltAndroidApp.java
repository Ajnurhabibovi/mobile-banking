package com.example.mb.app;

public @interface HiltAndroidApp {
}
